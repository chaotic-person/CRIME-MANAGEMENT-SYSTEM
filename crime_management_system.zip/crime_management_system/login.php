<?php
session_start();

// Database config
$host = "localhost";
$user = "root";
$password = "";
$database = "crime_management_cj";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['login'])) {
        // Login form submitted
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        $stmt = $conn->prepare("SELECT * FROM Users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password_hash'])) {
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                header("Location:home_page.php");
                exit();
            } else {
                $message = "❌ Incorrect password.";
            }
        } else {
            $message = "❌ User not found.";
        }

        $stmt->close();

    } elseif (isset($_POST['register'])) {
        // Register form submitted
        $newUsername = trim($_POST['new_username']);
        $newPassword = trim($_POST['new_password']);
        $role = $_POST['role'];

        if (strlen($newPassword) < 6) {
            $message = "❌ Password must be at least 6 characters.";
        } else {
            $hash = password_hash($newPassword, PASSWORD_DEFAULT);

            $check = $conn->prepare("SELECT * FROM Users WHERE username = ?");
            $check->bind_param("s", $newUsername);
            $check->execute();
            $checkResult = $check->get_result();

            if ($checkResult->num_rows > 0) {
                $message = "❌ Username already exists.";
            } else {
                $stmt = $conn->prepare("INSERT INTO Users (username, password_hash, role) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $newUsername, $hash, $role);
                if ($stmt->execute()) {
                    $message = "✅ User created successfully!";
                } else {
                    $message = "❌ Error creating user.";
                }
                $stmt->close();
            }
            $check->close();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Crime Management Login</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: linear-gradient(to right, #2c5364, #203a43, #0f2027);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .container {
      background: rgba(0, 0, 0, 0.85);
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 0 15px #00ffe0;
      width: 340px;
    }

    .tab-buttons {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
    }

    .tab-buttons button {
      background: #00ffe0;
      border: none;
      padding: 10px;
      width: 48%;
      font-weight: bold;
      cursor: pointer;
    }

    .tab-buttons button.active {
      background: #00ccb3;
    }

    .form-container {
      display: none;
    }

    .form-container.active {
      display: block;
    }

    .form-group {
      position: relative;
      margin-bottom: 25px;
    }

    .form-group input, .form-group select {
      width: 100%;
      padding: 10px;
      background: none;
      border: none;
      border-bottom: 1px solid #fff;
      color: #fff;
      font-size: 16px;
      outline: none;
    }

    .form-group label {
      position: absolute;
      top: 10px;
      left: 0;
      color: #aaa;
      font-size: 16px;
      transition: 0.5s;
      pointer-events: none;
    }

    .form-group input:focus ~ label,
    .form-group input:valid ~ label {
      top: -18px;
      color: #00ffe0;
      font-size: 12px;
    }

    button[type="submit"] {
      width: 100%;
      background: #00ffe0;
      color: #000;
      padding: 10px;
      border: none;
      cursor: pointer;
      font-weight: bold;
      border-radius: 5px;
      transition: 0.3s;
    }

    button[type="submit"]:hover {
      background: #00ccb3;
    }

    .message {
      text-align: center;
      color: #f88;
      font-weight: bold;
      margin-bottom: 15px;
    }

    h2 {
      color: #fff;
      text-align: center;
      margin-bottom: 20px;
    }
  </style>

  <script>
    function showTab(tab) {
      document.querySelectorAll('.form-container').forEach(f => f.classList.remove('active'));
      document.querySelectorAll('.tab-buttons button').forEach(b => b.classList.remove('active'));
      document.getElementById(tab).classList.add('active');
      document.getElementById(tab + "-btn").classList.add('active');
    }

    window.onload = () => {
      showTab('login-form'); // default tab
    }
  </script>
</head>
<body>
  <div class="container">
    <div class="tab-buttons">
      <button id="login-form-btn" onclick="showTab('login-form')">Login</button>
      <button id="register-form-btn" onclick="showTab('register-form')">Create User</button>
    </div>

    <?php if ($message): ?>
      <div class="message"><?= $message ?></div>
    <?php endif; ?>

    <!-- Login Form -->
    <div id="login-form" class="form-container">
      <h2>Login</h2>
      <form method="POST">
        <div class="form-group">
          <input type="text" name="username" required>
          <label>Username</label>
        </div>
        <div class="form-group">
          <input type="password" name="password" required>
          <label>Password</label>
        </div>
        <button type="submit" name="login">Login</button>
      </form>
    </div>

    <!-- Create User Form -->
    <div id="register-form" class="form-container">
      <h2>Create User</h2>
      <form method="POST">
        <div class="form-group">
          <input type="text" name="new_username" required>
          <label>New Username</label>
        </div>
        <div class="form-group">
          <input type="password" name="new_password" required>
          <label>New Password</label>
        </div>
        <div class="form-group">
          <select name="role" required>
            <option value="Officer">Officer</option>
            <option value="Admin">Admin</option>
            <option value="User">User</option>
          </select>
        </div>
        <button type="submit" name="register">Create</button>
      </form>
    </div>
  </div>
</body>
</html>
