<?php
session_start();

// Check if the user is logged in and is an Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "crime_management_cj";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all users (excluding the Admin itself)
$sql = "SELECT * FROM Users WHERE role != 'Admin'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users</title>
    <style>
        /* Basic styling, similar to your other pages */
        body {
            font-family: Arial, sans-serif;
            background: #2c5364;
            color: white;
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 20px;
        }
        .user-list {
            margin-top: 20px;
        }
        .user-item {
            background: #1f2a34;
            margin-bottom: 10px;
            padding: 15px;
            border-radius: 5px;
        }
        .user-item h3 {
            color: #00ffe0;
            margin: 0;
        }
        .user-item a {
            color: #d6dbdf;
            text-decoration: none;
        }
        .user-item select {
            padding: 5px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Manage Users</h2>
        <div class="user-list">
            <?php while ($user = $result->fetch_assoc()): ?>
                <div class="user-item">
                    <h3><?= htmlspecialchars($user['username']) ?></h3>
                    <p>Role: <?= htmlspecialchars($user['role']) ?></p>

                    <!-- Edit and Delete options -->
                    <form action="edit_user.php" method="GET" style="display:inline;">
                        <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                        <button type="submit" style="background:#27ae60; color:white; border:none; padding: 5px 10px; cursor:pointer;">Edit Role</button>
                    </form>

                    <form action="delete_user.php" method="POST" style="display:inline;">
                        <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                        <button type="submit" onclick="return confirm('Are you sure you want to delete this user?');" style="background:#c0392b; color:white; border:none; padding: 5px 10px; cursor:pointer;">Delete</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
