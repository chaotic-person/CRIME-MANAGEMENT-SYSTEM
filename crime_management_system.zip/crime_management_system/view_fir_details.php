<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database config
$host = "localhost";
$user = "root";
$password = "";
$database = "crime_management_cj";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get FIR ID from the URL
if (!isset($_GET['fir_id'])) {
    echo "FIR ID is required.";
    exit();
}

$fir_id = $_GET['fir_id'];

// Fetch FIR details
$fir_query = "SELECT * FROM FIR WHERE fir_id = ?";
$fir_stmt = $conn->prepare($fir_query);
$fir_stmt->bind_param("i", $fir_id);
$fir_stmt->execute();
$fir_result = $fir_stmt->get_result();
$fir_details = $fir_result->fetch_assoc();

if (!$fir_details) {
    echo "FIR not found.";
    exit();
}

// Get officer name for the FIR
$officer_query = "SELECT name FROM PoliceOfficers WHERE officer_id = ?";
$officer_stmt = $conn->prepare($officer_query);
$officer_stmt->bind_param("i", $fir_details['filed_by_officer_id']);
$officer_stmt->execute();
$officer_result = $officer_stmt->get_result();
$officer_name = $officer_result->fetch_assoc()['name'];

// Get victims for this FIR
$victim_query = "SELECT name FROM Victims WHERE fir_id = ?";
$victim_stmt = $conn->prepare($victim_query);
$victim_stmt->bind_param("i", $fir_id);
$victim_stmt->execute();
$victim_result = $victim_stmt->get_result();
$victims = [];
while ($victim = $victim_result->fetch_assoc()) {
    $victims[] = $victim['name'];
}

// Get accused for this FIR
$accused_query = "SELECT name FROM Accused WHERE fir_id = ?";
$accused_stmt = $conn->prepare($accused_query);
$accused_stmt->bind_param("i", $fir_id);
$accused_stmt->execute();
$accused_result = $accused_stmt->get_result();
$accused = [];
while ($accused_person = $accused_result->fetch_assoc()) {
    $accused[] = $accused_person['name'];
}

// Get upcoming court hearings for this FIR
$court_query = "SELECT court_name, hearing_date FROM CourtDetails WHERE fir_id = ? AND hearing_date > NOW() ORDER BY hearing_date ASC";
$court_stmt = $conn->prepare($court_query);
$court_stmt->bind_param("i", $fir_id);
$court_stmt->execute();
$court_result = $court_stmt->get_result();
$court_hearings = [];
while ($row = $court_result->fetch_assoc()) {
    $court_hearings[] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>FIR Details</title>
    <style>
        body {
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364); /* Deep gradient */
            color: #ecf0f1;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            margin: 40px auto;
            background: #1c2833;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
        }

        h2 {
            text-align: center;
            color: #ffffff;
        }

        .detail-box {
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid #566573;
            border-radius: 8px;
            background-color: #212f3c;
        }

        .detail-box label {
            font-weight: bold;
            color: #ecf0f1;
        }

        .detail-box p {
            margin: 5px 0;
            color: #d6dbdf;
        }

        .back {
            text-align: center;
            margin-top: 20px;
        }

        .back a {
            text-decoration: none;
            color: #d6dbdf;
        }

        .button {
            background-color: #273746;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #1a242f;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>FIR Details</h2>

        <!-- FIR Details -->
        <div class="detail-box">
            <label>FIR Number:</label>
            <p><?= htmlspecialchars($fir_details['fir_number']) ?></p>

            <label>Date Filed:</label>
            <p><?= htmlspecialchars($fir_details['date_filed']) ?></p>

            <label>Filed By Officer:</label>
            <p><?= htmlspecialchars($officer_name) ?></p>

            <label>Status:</label>
            <p><?= htmlspecialchars($fir_details['status']) ?></p>

            <label>Complaint Text:</label>
            <p><?= htmlspecialchars($fir_details['complaint_text']) ?></p>
        </div>

        <!-- Victims -->
        <div class="detail-box">
            <label>Victims:</label>
            <p><?= empty($victims) ? 'No victims added.' : implode(', ', $victims) ?></p>
        </div>

        <!-- Accused -->
        <div class="detail-box">
            <label>Accused:</label>
            <p><?= empty($accused) ? 'No accused added.' : implode(', ', $accused) ?></p>
        </div>

        <!-- Upcoming Court Hearings -->
        <?php if (!empty($court_hearings)): ?>
            <div class="detail-box">
                <label>Upcoming Court Hearings:</label>
                <?php foreach ($court_hearings as $hearing): ?>
                    <p><strong>Court:</strong> <?= htmlspecialchars($hearing['court_name']) ?></p>
                    <p><strong>Date:</strong> <?= htmlspecialchars($hearing['hearing_date']) ?></p>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="detail-box">
                <label>Upcoming Court Hearings:</label>
                <p>No upcoming hearings scheduled.</p>
            </div>
        <?php endif; ?>

        <div class="back">
            <a href="view_cases.php">← Back to View Cases</a>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
