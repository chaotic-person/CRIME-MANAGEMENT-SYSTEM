<?php
session_start();

// Check if user is logged in and is an Admin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Admin', 'Officer'])) {
    header("Location: login.php");
    exit();
}

// Database config
$host = "localhost";
$user = "root";
$password = "";
$database = "crime_management_cj";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

// Add Officer
if (isset($_POST['add_officer'])) {
    $name = trim($_POST['name']);
    $badge_number = trim($_POST['badge_number']);
    $rank = trim($_POST['rank']);
    $police_station = trim($_POST['police_station']);
    $contact_number = trim($_POST['contact_number']);

    $stmt = $conn->prepare("INSERT INTO PoliceOfficers (name, badge_number, rank, police_station, contact_number) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $badge_number, $rank, $police_station, $contact_number);

    if ($stmt->execute()) {
        $message = "✅ Officer added successfully!";
    } else {
        $message = "❌ Error adding officer.";
    }
    $stmt->close();
}

// Update Officer
if (isset($_POST['update_officer'])) {
    $officer_id = $_POST['officer_id'];
    $name = trim($_POST['name']);
    $badge_number = trim($_POST['badge_number']);
    $rank = trim($_POST['rank']);
    $police_station = trim($_POST['police_station']);
    $contact_number = trim($_POST['contact_number']);

    $stmt = $conn->prepare("UPDATE PoliceOfficers SET name = ?, badge_number = ?, rank = ?, police_station = ?, contact_number = ? WHERE officer_id = ?");
    $stmt->bind_param("sssssi", $name, $badge_number, $rank, $police_station, $contact_number, $officer_id);

    if ($stmt->execute()) {
        $message = "✅ Officer updated successfully!";
    } else {
        $message = "❌ Error updating officer.";
    }
    $stmt->close();
}

// Delete Officer
if (isset($_GET['delete_officer_id'])) {
    $officer_id = $_GET['delete_officer_id'];

    $stmt = $conn->prepare("DELETE FROM PoliceOfficers WHERE officer_id = ?");
    $stmt->bind_param("i", $officer_id);

    if ($stmt->execute()) {
        $message = "✅ Officer deleted successfully!";
    } else {
        $message = "❌ Error deleting officer.";
    }
    $stmt->close();
}

// Fetch officers for the list view
$result = $conn->query("SELECT * FROM PoliceOfficers");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Officers - Crime Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #2c5364, #203a43, #0f2027);
            color: white;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #333;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }
        .navbar a:hover {
            background-color: #575757;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .container {
            padding: 40px;
        }
        .message {
            color: #f88;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
        .officer-list {
            width: 100%;
            margin-top: 20px;
        }
        .officer-list th, .officer-list td {
            padding: 10px;
            border: 1px solid #ddd;
        }
        .officer-list th {
            background-color: #333;
        }
        .officer-list td {
            background-color: #444;
        }
        .button {
            padding: 10px;
            background-color: #00ffe0;
            color: black;
            text-decoration: none;
            border-radius: 5px;
        }
        .button:hover {
            background-color: #00ccb3;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="home_.php">Home</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <div class="message"><?= $message ?></div>
        <?php endif; ?>

        <h2>Manage Officers</h2>

        <!-- Add Officer Form -->
        <h3>Add New Officer</h3>
        <form method="POST">
            <label>Name:</label><br>
            <input type="text" name="name" required><br><br>
            <label>Badge Number:</label><br>
            <input type="text" name="badge_number" required><br><br>
            <label>Rank:</label><br>
            <input type="text" name="rank" required><br><br>
            <label>Police Station:</label><br>
            <input type="text" name="police_station" required><br><br>
            <label>Contact Number:</label><br>
            <input type="text" name="contact_number" required><br><br>
            <button type="submit" name="add_officer" class="button">Add Officer</button>
        </form>

        <h3>Officer List</h3>
        <table class="officer-list">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Badge Number</th>
                    <th>Rank</th>
                    <th>Police Station</th>
                    <th>Contact Number</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($officer = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($officer['name']) ?></td>
                        <td><?= htmlspecialchars($officer['badge_number']) ?></td>
                        <td><?= htmlspecialchars($officer['rank']) ?></td>
                        <td><?= htmlspecialchars($officer['police_station']) ?></td>
                        <td><?= htmlspecialchars($officer['contact_number']) ?></td>
                        <td>
                            <a href="update_officer.php?officer_id=<?= $officer['officer_id'] ?>" class="button">Update</a>
                            <a href="?delete_officer_id=<?= $officer['officer_id'] ?>" class="button" onclick="return confirm('Are you sure you want to delete this officer?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
