<?php
session_start();

// Check if the user is logged in and is an Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "crime_management_cj";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID from URL
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;
if ($user_id === null) {
    echo "Invalid user ID.";
    exit();
}

// Fetch user details
$sql = "SELECT * FROM Users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_assoc();

if (!$user) {
    echo "User not found.";
    exit();
}

// Handle form submission to update role
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_role = $_POST['role'];
    $update_sql = "UPDATE Users SET role = ? WHERE user_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("si", $new_role, $user_id);
    $update_stmt->execute();
    header("Location: manage_users.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User Role</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #2c5364;
            color: white;
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 20px;
        }
        label {
            display: block;
            margin: 10px 0;
        }
        select {
            padding: 5px;
        }
        button {
            background-color: #27ae60;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit User Role</h2>

        <form method="POST">
            <label for="username">Username: <?= htmlspecialchars($user['username']) ?></label>
            <label for="role">Select New Role:</label>
            <select name="role" id="role">
                <option value="User" <?= $user['role'] === 'User' ? 'selected' : '' ?>>User</option>
                <option value="Officer" <?= $user['role'] === 'Officer' ? 'selected' : '' ?>>Officer</option>
                <option value="Admin" <?= $user['role'] === 'Admin' ? 'selected' : '' ?>>Admin</option>
            </select>
            <br><br>
            <button type="submit">Update Role</button>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
