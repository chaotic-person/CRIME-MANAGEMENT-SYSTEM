<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database config
$host = "localhost";
$user = "root";
$password = "";
$database = "crime_management_cj";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle search request
$search_fir_number = '';
$search_status = '';
$where_clause = '';

// Check if search form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search_fir_number = $_POST['search_fir_number'];
    $search_status = $_POST['search_status'];

    $where_clause = "WHERE 1=1"; // Default condition for search
    if (!empty($search_fir_number)) {
        $where_clause .= " AND fir_number LIKE ?";
    }
    if (!empty($search_status)) {
        $where_clause .= " AND status = ?";
    }
}

// Get all FIRs with search criteria
$query = "SELECT * FROM FIR $where_clause";
$stmt = $conn->prepare($query);

// Bind parameters for search
if (!empty($search_fir_number) && !empty($search_status)) {
    $search_fir_number = "%" . $search_fir_number . "%";
    $stmt->bind_param("ss", $search_fir_number, $search_status);
} elseif (!empty($search_fir_number)) {
    $search_fir_number = "%" . $search_fir_number . "%";
    $stmt->bind_param("s", $search_fir_number);
} elseif (!empty($search_status)) {
    $stmt->bind_param("s", $search_status);
}

$stmt->execute();
$result = $stmt->get_result();

// Fetch the details for each FIR
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Cases</title>
    <style>
        body {
    background: linear-gradient(135deg, #0f2027, #203a43, #2c5364); /* Dark gradient */
    color: #ecf0f1;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

.container {
    width: 90%;
    margin: 40px auto;
    background: #1c2833;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
}

h2 {
    text-align: center;
    color: #ffffff;
}

table {
    width: 100%;
    border-collapse: collapse;
    border: 1px solid #566573;
}

th, td {
    padding: 12px;
    text-align: left;
    border: 1px solid #566573;
}

th {
    background-color: #273746;
    color: #ecf0f1;
}

td {
    background-color: #212f3c;
    color: #ecf0f1;
}

.button {
    background-color: #273746;
    color: white;
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.button:hover {
    background-color: #1a242f;
}

.search-container {
    margin-bottom: 20px;
    display: flex;
    justify-content: flex-end;
}

input[type="text"] {
    padding: 8px;
    border-radius: 5px;
    border: 1px solid #566573;
    background-color: #212f3c;
    color: #ecf0f1;
}

.back {
    text-align: center;
    margin-top: 20px;
}

.back a {
    text-decoration: none;
    color: #d6dbdf;
}

.error {
    color: #e74c3c;
    text-align: center;
}

    </style>
</head>
<body>
    <div class="container">
        <h2>All Filed Cases</h2>

        <!-- Search Form -->
        <div class="search-container">
            <form method="POST">
                <label for="search_fir_number">Search by FIR Number:</label>
                <input type="text" name="search_fir_number" value="<?= htmlspecialchars($search_fir_number) ?>" placeholder="Enter FIR Number">
                
                <label for="search_status">Search by Status:</label>
                <select name="search_status">
                    <option value="">-- Select Status --</option>
                    <option value="Registered" <?= $search_status == 'Registered' ? 'selected' : '' ?>>Registered</option>
                    <option value="Under Investigation" <?= $search_status == 'Under Investigation' ? 'selected' : '' ?>>Under Investigation</option>
                    <option value="Closed" <?= $search_status == 'Closed' ? 'selected' : '' ?>>Closed</option>
                </select>

                <button type="submit" class="button">Search</button>
            </form>
        </div>

        <!-- FIRs Table -->
        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>FIR Number</th>
                        <th>Date Filed</th>
                        <th>Filed By Officer</th>
                        <th>Status</th>
                        <th>Victims</th>
                        <th>Accused</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <?php
                        // Get officer name for the FIR
                        $officer_query = "SELECT name FROM PoliceOfficers WHERE officer_id = ?";
                        $officer_stmt = $conn->prepare($officer_query);
                        $officer_stmt->bind_param("i", $row['filed_by_officer_id']);
                        $officer_stmt->execute();
                        $officer_result = $officer_stmt->get_result();
                        $officer_name = $officer_result->fetch_assoc()['name'];

                        // Get victims for this FIR
                        $victim_query = "SELECT name FROM Victims WHERE fir_id = ?";
                        $victim_stmt = $conn->prepare($victim_query);
                        $victim_stmt->bind_param("i", $row['fir_id']);
                        $victim_stmt->execute();
                        $victim_result = $victim_stmt->get_result();
                        $victims = [];
                        while ($victim = $victim_result->fetch_assoc()) {
                            $victims[] = $victim['name'];
                        }

                        // Get accused for this FIR
                        $accused_query = "SELECT name FROM Accused WHERE fir_id = ?";
                        $accused_stmt = $conn->prepare($accused_query);
                        $accused_stmt->bind_param("i", $row['fir_id']);
                        $accused_stmt->execute();
                        $accused_result = $accused_stmt->get_result();
                        $accused = [];
                        while ($accused_person = $accused_result->fetch_assoc()) {
                            $accused[] = $accused_person['name'];
                        }
                        ?>

                        <tr>
                            <td><?= htmlspecialchars($row['fir_number']) ?></td>
                            <td><?= htmlspecialchars($row['date_filed']) ?></td>
                            <td><?= htmlspecialchars($officer_name) ?></td>
                            <td><?= htmlspecialchars($row['status']) ?></td>
                            <td><?= implode(", ", $victims) ?></td>
                            <td><?= implode(", ", $accused) ?></td>
                            <td>
                                <a href="view_fir_details.php?fir_id=<?= $row['fir_id'] ?>" class="button">View Details</a>
                            </td>
                        </tr>

                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No FIRs found.</p>
        <?php endif; ?>

        <div class="back">
            <a href="home_page.php">← Back to Home</a>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
