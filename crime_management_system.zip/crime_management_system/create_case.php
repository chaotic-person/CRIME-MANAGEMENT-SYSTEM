<?php
session_start();

// Access Control: only Admin and Officer
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'Admin' && $_SESSION['role'] !== 'Officer')) {
    header("Location: login.php");
    exit();
}

// DB config
$host = "localhost";
$user = "root";
$password = "";
$database = "crime_management_cj";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$fir_exists = false;

// On form submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fir_number = $_POST['fir_number'];
    $date_filed = $_POST['date_filed'];
    $filed_by = $_POST['filed_by_officer_id'];
    $complaint_text = $_POST['complaint_text'];
    $location = $_POST['location'];
    $status = $_POST['status'];

    // Check for FIR number duplication
    $check = $conn->prepare("SELECT * FROM FIR WHERE fir_number = ?");
    $check->bind_param("s", $fir_number);
    $check->execute();
    $result = $check->get_result();
    if ($result->num_rows > 0) {
        $fir_exists = true;
    } else {
        // Insert into FIR
        $stmt = $conn->prepare("INSERT INTO FIR (fir_number, date_filed, filed_by_officer_id, complaint_text, location, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisss", $fir_number, $date_filed, $filed_by, $complaint_text, $location, $status);
        if ($stmt->execute()) {
            $fir_id = $stmt->insert_id;

            // Insert victims
            for ($i = 0; $i < count($_POST['victim_name']); $i++) {
                $vname = $_POST['victim_name'][$i];
                $vage = $_POST['victim_age'][$i];
                $vgender = $_POST['victim_gender'][$i];
                $vaddress = $_POST['victim_address'][$i];
                $vcontact = $_POST['victim_contact'][$i];

                if ($vname != "") {
                    $stmt_victim = $conn->prepare("INSERT INTO Victims (fir_id, name, age, gender, address, contact_number) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt_victim->bind_param("isisss", $fir_id, $vname, $vage, $vgender, $vaddress, $vcontact);
                    $stmt_victim->execute();
                }
            }

            // Insert accused
            for ($i = 0; $i < count($_POST['accused_name']); $i++) {
                $aname = $_POST['accused_name'][$i];
                $aage = $_POST['accused_age'][$i];
                $agender = $_POST['accused_gender'][$i];
                $aaddress = $_POST['accused_address'][$i];
                $astatus = $_POST['accused_status'][$i];

                if ($aname != "") {
                    $stmt_accused = $conn->prepare("INSERT INTO Accused (fir_id, name, age, gender, address, status) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt_accused->bind_param("isisss", $fir_id, $aname, $aage, $agender, $aaddress, $astatus);
                    $stmt_accused->execute();
                }
            }

            $message = "FIR successfully submitted.";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}

// Get officers
$officers = $conn->query("SELECT officer_id, name FROM PoliceOfficers");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create FIR</title>
    <style>
     body {
    background: linear-gradient(135deg, #0f2027, #203a43, #2c5364); /* Dark gradient */
    color: #ecf0f1; /* Soft white text */
    font-family: Arial, sans-serif;
}

.container {
    width: 80%;
    margin: 40px auto;
    background: #1c2833; /* Darker container to match card style */
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
}

h2 {
    text-align: center;
    color: #ffffff;
}

label {
    font-weight: bold;
    color: #d0d3d4;
}

input, select, textarea {
    width: 100%;
    padding: 10px;
    margin-top: 6px;
    margin-bottom: 20px;
    border: 1px solid #566573;
    border-radius: 5px;
    background-color: #212f3c;
    color: #ecf0f1;
}

textarea {
    height: 80px;
}

.group-box {
    margin-bottom: 30px;
    padding: 15px;
    border: 1px solid #566573;
    border-radius: 8px;
    background-color: #1b2631;
}

.button {
    background-color: #273746;
    color: white;
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.button:hover {
    background-color: #1a242f;
}

.message {
    text-align: center;
    color: #2ecc71;
    font-weight: bold;
}

.error {
    color: #e74c3c;
    text-align: center;
}

.back {
    text-align: center;
    margin-top: 20px;
}

.back a {
    text-decoration: none;
    color: #d6dbdf;
}


    </style>
    <script>
        let victimCount = 1;
        let accusedCount = 1;

        function addVictim() {
            if (victimCount >= 5) return;
            victimCount++;
            let container = document.getElementById("victims");
            let html = `
                <div class="group-box">
                    <label>Name:</label>
                    <input type="text" name="victim_name[]">
                    <label>Age:</label>
                    <input type="number" name="victim_age[]">
                    <label>Gender:</label>
                    <select name="victim_gender[]">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                    <label>Address:</label>
                    <input type="text" name="victim_address[]">
                    <label>Contact Number:</label>
                    <input type="text" name="victim_contact[]">
                </div>`;
            container.insertAdjacentHTML('beforeend', html);
        }

        function addAccused() {
            if (accusedCount >= 5) return;
            accusedCount++;
            let container = document.getElementById("accused");
            let html = `
                <div class="group-box">
                    <label>Name:</label>
                    <input type="text" name="accused_name[]">
                    <label>Age:</label>
                    <input type="number" name="accused_age[]">
                    <label>Gender:</label>
                    <select name="accused_gender[]">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                    <label>Address:</label>
                    <input type="text" name="accused_address[]">
                    <label>Status:</label>
                    <select name="accused_status[]">
                        <option value="At Large">At Large</option>
                        <option value="Arrested">Arrested</option>
                        <option value="Released on Bail">Released on Bail</option>
                        <option value="Convicted">Convicted</option>
                    </select>
                </div>`;
            container.insertAdjacentHTML('beforeend', html);
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Create New FIR</h2>

        <?php
        if ($fir_exists) echo "<p class='error'>FIR number already exists.</p>";
        elseif ($message) echo "<p class='message'>$message</p>";
        ?>

        <form method="POST">
            <label>FIR Number:</label>
            <input type="text" name="fir_number" required>

            <label>Date Filed:</label>
            <input type="date" name="date_filed" required>

            <label>Filed By Officer:</label>
            <select name="filed_by_officer_id" required>
                <option value="">-- Select Officer --</option>
                <?php while ($row = $officers->fetch_assoc()): ?>
                    <option value="<?= $row['officer_id'] ?>"><?= htmlspecialchars($row['name']) ?></option>
                <?php endwhile; ?>
            </select>

            <label>Complaint Text:</label>
            <textarea name="complaint_text" required></textarea>

            <label>Location:</label>
            <input type="text" name="location" required>

            <label>Status:</label>
            <select name="status" required>
                <option value="Registered">Registered</option>
                <option value="Under Investigation">Under Investigation</option>
                <option value="Closed">Closed</option>
            </select>

            <h3>Victims</h3>
            <div id="victims">
                <div class="group-box">
                    <label>Name:</label>
                    <input type="text" name="victim_name[]">
                    <label>Age:</label>
                    <input type="number" name="victim_age[]">
                    <label>Gender:</label>
                    <select name="victim_gender[]">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                    <label>Address:</label>
                    <input type="text" name="victim_address[]">
                    <label>Contact Number:</label>
                    <input type="text" name="victim_contact[]">
                </div>
            </div>
            <button type="button" class="button" onclick="addVictim()">+ Add Victim</button>

            <h3>Accused</h3>
            <div id="accused">
                <div class="group-box">
                    <label>Name:</label>
                    <input type="text" name="accused_name[]">
                    <label>Age:</label>
                    <input type="number" name="accused_age[]">
                    <label>Gender:</label>
                    <select name="accused_gender[]">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                    <label>Address:</label>
                    <input type="text" name="accused_address[]">
                    <label>Status:</label>
                    <select name="accused_status[]">
                        <option value="At Large">At Large</option>
                        <option value="Arrested">Arrested</option>
                        <option value="Released on Bail">Released on Bail</option>
                        <option value="Convicted">Convicted</option>
                    </select>
                </div>
            </div>
            <button type="button" class="button" onclick="addAccused()">+ Add Accused</button><br><br>

            <button class="button" type="submit">Submit FIR</button>
        </form>

        <div class="back">
            <a href="home_page.php">← Back to Home</a>
        </div>
    </div>
</body>
</html>
