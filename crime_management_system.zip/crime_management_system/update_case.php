<?php
session_start();

// Only Admins and Officers
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Admin','Officer'])) {
    header("Location: login.php");
    exit();
}

// DB connection
$host="localhost"; $user="root"; $pw=""; $db="crime_management_cj";
$conn=new mysqli($host,$user,$pw,$db);
if($conn->connect_error) die("Connection failed: ".$conn->connect_error);

$message = "";

// If fir_id is passed, handle form submission
if(isset($_GET['fir_id'])) {
    $fir_id = intval($_GET['fir_id']);

    // Handle new hearing submission
    if($_SERVER['REQUEST_METHOD']==='POST') {
        $court_name = trim($_POST['court_name']);
        $hearing_date = $_POST['hearing_date'];

        $stmt = $conn->prepare("
            INSERT INTO CourtDetails (fir_id, court_name, hearing_date, case_status)
            VALUES (?, ?, ?, 'Pending')
        ");
        $stmt->bind_param("iss", $fir_id, $court_name, $hearing_date);
        if($stmt->execute()) {
            $message = "✅ Hearing added.";
        } else {
            $message = "❌ Error: ".$conn->error;
        }
        $stmt->close();
    }

    // Fetch FIR
    $f = $conn->prepare("SELECT fir_number, date_filed, status FROM FIR WHERE fir_id=?");
    $f->bind_param("i",$fir_id); $f->execute();
    $fir = $f->get_result()->fetch_assoc();
    $f->close();

    // Fetch victims
    $v = $conn->prepare("SELECT name FROM Victims WHERE fir_id=?");
    $v->bind_param("i",$fir_id); $v->execute();
    $victims = $v->get_result()->fetch_all(MYSQLI_ASSOC);
    $v->close();

    // Fetch accused
    $a = $conn->prepare("SELECT name FROM Accused WHERE fir_id=?");
    $a->bind_param("i",$fir_id); $a->execute();
    $accused = $a->get_result()->fetch_all(MYSQLI_ASSOC);
    $a->close();
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Update Case Hearing</title>
<style>
  body {
  background: linear-gradient(to right, #0f2027, #203a43, #2c5364); 
  color: white;
  font-family: Arial, sans-serif;
}

.container {
  width: 80%;
  margin: 40px auto;
  background: #1b2a35; /* deep navy background */
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
}

h2 {
  text-align: center;
  color: #ecf0f1;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin: 20px 0;
}

th, td {
  padding: 10px;
  border: 1px solid #566573;
  text-align: left;
}

th {
  background: #111921;
  color: white;
}

td {
  background: #ecf0f1;
  color: #2c3e50;
}

.button {
  background: #111921;
  color: white;
  padding: 8px 16px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.button:hover {
  background: #1e2a35;
}

form {
  margin-top: 30px;
}

label {
  display: block;
  margin-top: 15px;
  font-weight: bold;
}

input[type="text"], input[type="date"] {
  width: 100%;
  padding: 10px;
  margin-top: 5px;
  border-radius: 5px;
  border: 1px solid #566573;
}

.message {
  text-align: center;
  margin-top: 20px;
  font-weight: bold;
}

.back {
  text-align: center;
  margin-top: 30px;
}

.back a {
  color: #ecf0f1;
  text-decoration: none;
}

</style>
</head>
<body>
<div class="container">
  <?php if(!isset($fir_id)): ?>
    <!-- List FIRs to pick one -->
    <h2>Select Case to Update Hearing</h2>
    <table>
      <thead>
        <tr><th>FIR Number</th><th>Date Filed</th><th>Status</th><th>Action</th></tr>
      </thead>
      <tbody>
      <?php
      $all = $conn->query("SELECT fir_id, fir_number, date_filed, status FROM FIR");
      while($r = $all->fetch_assoc()):
      ?>
        <tr>
          <td><?=htmlspecialchars($r['fir_number'])?></td>
          <td><?=$r['date_filed']?></td>
          <td><?=htmlspecialchars($r['status'])?></td>
          <td>
            <a href="?fir_id=<?=$r['fir_id']?>" class="button">Update Hearing</a>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>

  <?php else: ?>
    <!-- Show details for chosen FIR -->
    <h2>FIR: <?=htmlspecialchars($fir['fir_number'])?></h2>
    <?php if($message): ?>
      <p class="message"><?=$message?></p>
    <?php endif; ?>

    <h3>Victims</h3>
    <table>
      <?php foreach($victims as $v): ?>
      <tr><td><?=htmlspecialchars($v['name'])?></td></tr>
      <?php endforeach; ?>
    </table>

    <h3>Accused</h3>
    <table>
      <?php foreach($accused as $a): ?>
      <tr><td><?=htmlspecialchars($a['name'])?></td></tr>
      <?php endforeach; ?>
    </table>

    <!-- Form to add a new hearing -->
    <form method="POST">
      <label for="court_name">Court Name</label>
      <input type="text" name="court_name" id="court_name" required>

      <label for="hearing_date">Hearing Date</label>
      <input type="date" name="hearing_date" id="hearing_date" required>

      <button type="submit" class="button">Add Hearing</button>
    </form>
  <?php endif; ?>

  <div class="back">
    <a href="home_page.php">← Back to Home</a>
  </div>
</div>
</body>
</html>

<?php $conn->close(); ?>
