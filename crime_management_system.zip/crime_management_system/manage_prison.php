<?php
session_start();

// Allow Admin and Officer roles
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Admin', 'Officer'])) {
    header("Location: login.php");
    exit();
}

// Database config
$host = "localhost";
$user = "root";
$password = "";
$database = "crime_management_cj";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle release action
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['release_id'])) {
    $accused_id = intval($_POST['release_id']);
    $update_stmt = $conn->prepare("UPDATE Accused SET status = 'Released on Bail' WHERE accused_id = ?");
    $update_stmt->bind_param("i", $accused_id);
    $update_stmt->execute();
    $update_stmt->close();
}

// Fetch accused under 'Arrested' status
$sql = "
    SELECT a.accused_id, a.name, a.age, a.gender, a.address, f.fir_number
    FROM Accused a
    JOIN FIR f ON a.fir_id = f.fir_id
    WHERE a.status = 'Arrested'
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Prison</title>
    <style>
       body {
    background: linear-gradient(135deg, #0f2027, #203a43, #2c5364); /* Dark gradient */
    color: #ecf0f1;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

.container {
    width: 90%;
    margin: 40px auto;
    background: #1c2833;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(0,0,0,0.5);
}

h2 {
    text-align: center;
    color: #ffffff;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 30px;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #566573;
}

th {
    background-color: #273746;
    color: #ecf0f1;
}

td {
    background-color: #212f3c;
    color: #ecf0f1;
}

.button {
    background-color: #273746;
    color: white;
    padding: 8px 14px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.button:hover {
    background-color: #1a242f;
}

.back {
    text-align: center;
    margin-top: 20px;
}

.back a {
    text-decoration: none;
    color: #d6dbdf;
}

    </style>
</head>
<body>
<div class="container">
    <h2>Manage Prisoners</h2>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Address</th>
                <th>FIR Number</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= $row['age'] ?></td>
                    <td><?= $row['gender'] ?></td>
                    <td><?= htmlspecialchars($row['address']) ?></td>
                    <td><?= htmlspecialchars($row['fir_number']) ?></td>
                    <td>
                        <form method="POST" onsubmit="return confirm('Are you sure to release this prisoner?');">
                            <input type="hidden" name="release_id" value="<?= $row['accused_id'] ?>">
                            <button type="submit" class="button">Release</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p style="text-align:center; margin-top:20px;">No prisoners found under 'Arrested' status.</p>
    <?php endif; ?>

    <div class="back">
        <a href="home_page.php">← Back to Home</a>
    </div>
</div>
</body>
</html>
