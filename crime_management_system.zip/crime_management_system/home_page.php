<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "crime_management_cj";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user details
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM Users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$user_role = $_SESSION['role'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home - Crime Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #2c5364, #203a43, #0f2027);
            color: white;
            margin: 0;
            padding: 0;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #333;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }
        .navbar a:hover {
            background-color: #575757;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .user-profile {
            position: relative;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .profile-pic {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: #333;
            font-weight: bold;
        }
        .dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            background-color: #333;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            display: none;
            width: 200px;
        }
        .dropdown a {
            color: white;
            padding: 10px;
            text-decoration: none;
            display: block;
        }
        .dropdown a:hover {
            background-color: #575757;
        }
        .user-profile:hover .dropdown {
            display: block;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 40px 0;
            min-height: 80vh;
            text-align: center;
        }
        .dashboard-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            width: 100%;
            padding: 0 40px;
        }
        .option-card {
            background: #1f2a34;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s, transform 0.3s;
            cursor: pointer;
            text-align: center;
        }
        .option-card:hover {
            background-color: #00ffe0;
            transform: scale(1.05);
        }
        .option-card h3 {
            color: #fff;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div><a href="home_page.php">Home</a></div>
        <div class="user-profile">
            <div class="profile-pic">
                <?= strtoupper(substr($user['username'], 0, 1)) ?>
            </div>
            <div class="dropdown">
                <a href="#">Username: <?= htmlspecialchars($user['username']) ?></a>
                <a href="#">Role: <?= htmlspecialchars($user_role) ?></a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="dashboard-options">
            <?php if ($user_role === "Admin"): ?>
                <div class="option-card" onclick="window.location.href='manage_users.php'">
                    <h3>Manage Users</h3> <!-- Add this line to allow Admin to manage users -->
                </div>
             <?php endif; ?>
            <?php if ($user_role === "Admin" || $user_role === "Officer"): ?>
                <div class="option-card" onclick="window.location.href='view_cases.php'">
                    <h3>View All Cases</h3>
                </div>
                <div class="option-card" onclick="window.location.href='create_case.php'">
                    <h3>Create New Case</h3>
                </div>
                <div class="option-card" onclick="window.location.href='update_officer.php'">
                    <h3>Manage Officers</h3>
                </div>
                <div class="option-card" onclick="window.location.href='manage_prison.php'">
                    <h3>Manage Prison</h3>
                </div>
            <?php endif; ?>

            <?php if ($user_role === "Officer"): ?>
                <div class="option-card" onclick="window.location.href='update_case.php'">
                    <h3>Update Case Hiring</h3>
                </div>
            <?php endif; ?>

            <?php if ($user_role === "User"): ?>
                <div class="option-card" onclick="window.location.href='view_cases.php'">
                    <h3>View Cases</h3>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>