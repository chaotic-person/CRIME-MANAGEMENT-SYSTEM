<?php
session_start();

// Check if the user is logged in and is an Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "crime_management_cj";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID from POST request
$user_id = isset($_POST['user_id']) ? $_POST['user_id'] : null;
if ($user_id === null) {
    echo "Invalid user ID.";
    exit();
}

// Delete the user
$sql = "DELETE FROM Users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();

// Redirect back to the manage users page
header("Location: manage_users.php");
exit();
?>
